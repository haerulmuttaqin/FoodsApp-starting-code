# FoodsApp-starting-code
this is the initial code to take lessons on Haerul Muttaqin YouTube Channel

https://youtu.be/njTHtyzaBug
